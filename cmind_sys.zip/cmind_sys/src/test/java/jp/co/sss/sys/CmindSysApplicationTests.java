package jp.co.sss.sys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmindSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
